# os-i2it
os lab TE IT sppu
